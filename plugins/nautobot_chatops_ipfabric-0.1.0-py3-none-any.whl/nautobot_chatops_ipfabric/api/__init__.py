"""REST API module for ipfabric plugin."""

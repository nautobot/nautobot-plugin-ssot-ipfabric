"""Django urlpatterns declaration for ipfabric plugin."""
# from django.urls import path

urlpatterns = []

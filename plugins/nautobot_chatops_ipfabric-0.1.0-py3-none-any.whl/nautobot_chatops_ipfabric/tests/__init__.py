"""Unit tests for ipfabric plugin."""
